package game

Rule :: struct {}

