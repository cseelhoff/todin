package game

Attachable :: struct {}

